
import express from 'express';
const router = express.Router();

router.post('/analyze', (req, res) => {
  res.json({ outcome: "CONDITIONAL" });
});

export default router;
