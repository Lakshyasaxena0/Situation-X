
export default function ResultCard({ result }) {
  return <div>{result}</div>;
}
