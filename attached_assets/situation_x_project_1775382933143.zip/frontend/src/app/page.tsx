
export default function Home() {
  return <div>Situation X - Query Input</div>;
}
