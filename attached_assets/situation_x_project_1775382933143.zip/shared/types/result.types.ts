
export type Result = {
  outcome: "YES" | "NO" | "CONDITIONAL";
  confidence: "low" | "medium" | "high";
};
